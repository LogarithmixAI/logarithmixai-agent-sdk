import time
import threading

from flask import request, g
from agent_sdk.core.pipeline import Pipeline
from werkzeug.exceptions import HTTPException

pipeline = Pipeline()

def classify_event(status_code, duration, exc, timeout_threshold=4000, slow_threshold=1000):

    is_slow = duration and duration > slow_threshold
    is_timeout = duration and duration > timeout_threshold

    # 🔴 1. Timeout (highest priority)
    if is_timeout:
        return "REQUEST_TIMEOUT"

    # 🔴 2. Exception
    if exc:
        if is_slow:
            return "REQUEST_SLOW_FAILURE"
        return "REQUEST_FAILED_APPLICATION"

    # 🔴 3. Routing error
    if status_code == 404:
        return "REQUEST_FAILED_ROUTING"

    # 🔴 4. Server error
    if status_code and status_code >= 500:
        if is_slow:
            return "REQUEST_SLOW_FAILURE"
        return "REQUEST_FAILED_SERVER"

    # 🔴 5. Client error
    if status_code and status_code >= 400:
        return "REQUEST_FAILED_CLIENT"

    # 🟢 6. Success
    if is_slow:
        return "REQUEST_SUCCESS_SLOW"

    return "REQUEST_SUCCESS_FAST"


def init_flask(app):

    @app.before_request
    def _start_request():
        g.start_time = time.time()

        pipeline.create_trace(reset=True)
        pipeline.start("request", "http_request")  # main request span

        # 🔥 ALWAYS capture request entry
        pipeline.process(
            event_type="INCOMING_REQUEST",
            category="APPLICATION",
            status="STARTED",
            metrics={},
            data={
                "path": request.path,
                "method": request.method,
                "client_ip": request.remote_addr,
                "user_agent": request.headers.get("User-Agent"),
                "thread": threading.current_thread().name,
            },
            span_extra_data = {"path": request.path}
        )
    exc = None
    @app.after_request
    def _log_request(response):

        try:
            g.status_code = response.status_code
            status_code = response.status_code
            status = "SUCCESS" if status_code < 400 else "FAILURE"
            event_type = "RESPONSE"
            
            pipeline.process(
                event_type=event_type,
                category="APPLICATION",
                status=status,
                metrics={},
                data={
                    "path": request.path,
                    "method": request.method,
                    "status_code": status_code,
                    "client_ip": request.remote_addr,
                    "user_agent": request.headers.get("User-Agent"),
                    "thread": threading.current_thread().name,
                },
                span_extra_data = {"path": request.path}
            )
        
        except Exception:
            pass  # never break app
        
        return response

    @app.errorhandler(Exception)
    def _handle_error(e):
        exc = e
        g._error_logged = True

        # ✅ status code detect
        if isinstance(e, HTTPException):
            status_code = e.code
        else:
            status_code = 500
            
        pipeline.start("request_processing", "application_logic") # processing span


        pipeline.process(
            event_type="REQUEST_EXCEPTION",
            category="APPLICATION",
            status="FAILURE",
            metrics={},
            data={
                "path": request.path,
                "method": request.method,
                "exception_type": type(e).__name__,
                "message": str(e),
                "thread": threading.current_thread().name,
                "status_code": status_code   # ✅ add this
            },
        )
        
        pipeline.end(
            span_extra_data={
                "stage": "processing",
                "path": request.path,
                "method": request.method,
                "exception_type": type(e).__name__,
                "status_code": status_code
            }
        )
        return "Internal Server Error", status_code

    @app.teardown_request
    def _teardown(exc):
        if not pipeline.has_active_trace():
            return
        # ✅ ALWAYS clear trace
        duration = None
        status_code = getattr(g, "status_code", None)
        event_type = "REQUEST_UNKNOWN"
        try:
            end_time = time.time()
            start_time = getattr(g, "start_time", None)

            duration = int((end_time - start_time) * 1000) if start_time else None
            status_code = getattr(g, "status_code", None)

            # 🔥 classify event
            event_type = classify_event(
                status_code=status_code,
                duration=duration,
                exc=exc
            )

            pipeline.process(
                event_type="REQUEST_VERDICT",
                category="FINAL",
                status="FAILURE" if exc or (status_code and status_code >= 400) else "SUCCESS",
                metrics={
                    "status_code": status_code
                },
                data={
                    "classification": event_type,
                    "path": request.path,
                    "method": request.method,
                    "exception_type": type(exc).__name__ if exc else None,
                    "is_timeout": duration and duration > 4000,
                    "is_slow": duration and duration > 1000,
                    "thread": threading.current_thread().name,
                },
                span_extra_data = {"path": request.path}
            )
        except Exception:
            pass  # never break app

        finally:
            pipeline.end(
                span_extra_data={
                    "classification": event_type,
                    "path": request.path,
                    "method": request.method,
                    "status_code": status_code,
                    "duration_ms": duration,
                    "exception_type": type(exc).__name__ if exc else None,
                }
            )  # end request span
            pipeline.clear_trace(force_clear=True)  # ensure trace is cleared
