import sys
import traceback
import threading
import time
from IPython import get_ipython
from agent_sdk.core.sanitizer import SanitizerEngine
from agent_sdk.core.pipeline import Pipeline


# 🔥 globals (dedup + rate limit)
_recent_errors = set()
_last_exception_time = 0

# 🔐 sanitizer instance (reuse)
sanitizer = SanitizerEngine()
pipeline = Pipeline()

def classify_exception(exc_type, message):

    msg = (message or "").lower()
    exc = exc_type.lower()

    # 🔴 Timeout / latency
    if "timeout" in msg:
        return "EXCEPTION_TIMEOUT"

    # 🔴 Network
    if "connection" in msg:
        return "EXCEPTION_CONNECTION_ERROR"

    # 🔴 Database
    if "integrity" in exc or "constraint" in msg:
        return "EXCEPTION_DB_INTEGRITY"

    if "deadlock" in msg:
        return "EXCEPTION_DB_DEADLOCK"

    # 🔴 Auth
    if "unauthorized" in msg or "token" in msg:
        return "EXCEPTION_AUTH_ERROR"

    if "permission" in msg:
        return "EXCEPTION_PERMISSION_DENIED"

    # 🔴 Programming errors
    if exc in ["keyerror", "attributeerror", "typeerror"]:
        return "EXCEPTION_PROGRAMMING_ERROR"

    if exc in ["valueerror"]:
        return "EXCEPTION_VALIDATION_ERROR"

    # 🔴 Critical system
    if exc in ["memoryerror", "recursionerror"]:
        return "EXCEPTION_CRITICAL"

    return "EXCEPTION_GENERAL"

class ExceptionTracker:

    @staticmethod
    def install():
        sys.excepthook = ExceptionTracker.handle_exception
        # Python 3.8+ thread exception support
        if hasattr(threading, "excepthook"):
            threading.excepthook = ExceptionTracker.handle_thread_exception

        ip = get_ipython()
        if ip:
            def ipython_handler(shell, etype, evalue, tb, tb_offset=None):
                ExceptionTracker._process_exception(etype, evalue, tb, handled=False)

            ip.set_custom_exc((Exception,), ipython_handler)

    @staticmethod
    def handle_exception(exc_type, exc_value, exc_traceback):
        try:
            ExceptionTracker._process_exception(
                exc_type,
                exc_value,
                exc_traceback,
                handled=False
            )
        except Exception:
            print("Error in exception handler:", file=sys.stderr)
            traceback.print_exc()   

    @staticmethod
    def handle_thread_exception(args):
        try:
            ExceptionTracker._process_exception(
                args.exc_type,
                args.exc_value,
                args.exc_traceback,
                handled=False
            )
        except Exception:
            print("Error in thread exception handler:", file=sys.stderr)
            traceback.print_exc()

    @staticmethod
    def _process_exception(exc_type, exc_value, exc_traceback, handled):
        try:
            
            global _last_exception_time

            # ❌ ignore system exit events
            if issubclass(exc_type, (KeyboardInterrupt, SystemExit)):
                return

            # ⏱️ rate limiting (avoid spam)
            now = time.time()
            if now - _last_exception_time < 1:   # 1 sec window
                return
            _last_exception_time = now

            # 🔁 deduplication
            error_key = f"{exc_type.__name__}:{str(exc_value)}"
            if error_key in _recent_errors:
                return
                
            if len(_recent_errors) > 1000:
                _recent_errors.clear()

            # 📜 stacktrace
            stack = "".join(
                traceback.format_exception(exc_type, exc_value, exc_traceback)
            )

            # 🔐 sanitize stacktrace (important)
            stack = sanitizer.mask_by_pattern(stack)

            # 📍 last frame info
            last_trace = traceback.extract_tb(exc_traceback)[-1] if exc_traceback else None

            file_name = last_trace.filename if last_trace else None
            line_number = last_trace.lineno if last_trace else None
            function_name = last_trace.name if last_trace else None

            
            exception_type = exc_type.__name__
            message = str(exc_value)

            event_type = classify_exception(exception_type, message)

            create_span = not pipeline.has_active_trace()

            if create_span:
                pipeline.start("exception", "uncatchable_exception")

            payload = {
                "error_type": exc_type.__name__,
                "message": str(exc_value),
                "file": file_name,
                "line": line_number,
                "function": function_name,
                "thread": threading.current_thread().name,
                "stacktrace": stack[:500],  # limit stacktrace size
                "handled": handled,
            }

            pipeline.process(
                event_type=event_type,
                category="APPLICATION",
                status="FAILURE",
                data=payload,
                metrics={}
            )
            if create_span:
                pipeline.end(
                    span_extra_data={
                        "exception_type": exception_type,
                        "message": message,
                        "file": file_name,
                        "line": line_number,
                        "function": function_name,
                        "handled": handled
                    }
                )  # end main exception span

        except Exception as e:
            print("Error in exception processing:", file=sys.stderr)
            traceback.print_exc()
        


