from uuid import uuid4
import time

import inspect

class SpanError(Exception):
    def __init__(self, message, span_id=None):
        frame = inspect.currentframe().f_back  # caller frame

        self.message = message
        self.span_id = span_id
        self.file = frame.f_code.co_filename
        self.line = frame.f_lineno
        self.function = frame.f_code.co_name

        super().__init__(self._format_message())

    def _format_message(self):
        return f"{self.message} (File: {self.file}, Line: {self.line}, Func: {self.function})"

class Span:
    def __init__(self, trace_id, parent_span_id=None, name=None, span_type=None):
        self.span_id = str(uuid4())
        self.trace_id = trace_id

        self.parent_span_id = parent_span_id
        self.child_span_ids = []
        self.event_ids = []
        self.event_flow = []
        self.name = name
        self.span_type = span_type
        self.retry = {
            "enabled" : False,
            "attempts": 0,
        }
        self.status = "ACTIVE"
        self.start_time = None
        self.end_time = None
        self.duration = None
        self.outcome = None
        self.span_events = []   # 🔥 attach events here
        self.data = {}
        self.extra = {}


    def to_dict(self): 
        return {
        "span_id": self.span_id,
        "trace_id": self.trace_id,
        "parent_span_id": self.parent_span_id,
        "child_span_ids": self.child_span_ids,
        "event_ids": self.event_ids,
        "outcome": self.outcome,
        "event_flow": self.event_flow,
        "retry":self.retry,
        "name": self.name,
        "type": self.span_type,
        "status": self.status,
        "start_time": self.start_time,
        "end_time": self.end_time,
        "duration_ms": self.duration,
        "span_events": self.span_events,
        "extra": self.extra
    }
    
    def start_span(self):
    
        self.start_time = time.time()
    
    def end_span(self, extra_span:dict = None ):

        if not self.start_time:
            error = SpanError(
                message="Span must be started before ending",
                span_id=self.span_id
            )
            self.retry['attempts'] +=1
            # 🔥 attach error to span
            self.span_events.append({
                "type": "ERROR",
                "message": error.message,
                "span_id": error.span_id,
                "attempt" : self.retry['attempts'],
                "file": error.file,
                "line": error.line,
                "function": error.function,
                "timestamp": time.time()
            })

            raise error

        self.end_time = time.time()
        self.duration = round((self.end_time - self.start_time)*1000,3)
        self.retry['attempts'] += 1
        if self.retry['attempts'] > 1 :
            self.retry['enabled'] = True
            
        if self.retry["attempts"] < 2 :
            self.status = "COMPLETED"
            self.span_events.append({
                    "type": "SUCCESS",
                    "message" : "Store span in queue",
                    "attempt" : self.retry['attempts'],
                    "span_id": self.span_id,
                    "timestamp": time.time()
                })
        else: 
            self.status = "RECOVERED"
            self.span_events.append({
                    "type": "RETRY_SUCCESS",
                    "message": "Recovered from missing start_span via auto_start",
                    "attempt": self.retry['attempts'],
                    "recovery_strategy": "auto_start",
                    "span_id": self.span_id,
                    "timestamp": time.time()
                })

        self.data = self.to_dict()

        if extra_span:
            self.extra.update(extra_span)
        
        return self.data
    