import uuid
import time
from contextvars import ContextVar
from agent_sdk.core.context import Trace, Graph, CurrentSpan
from agent_sdk.core.span.span import Span
from agent_sdk.core.span.trace_graph import TraceGraph


class SpanEngine:

    def _get_graph(self):
        trace_id = Trace.get()
        if not trace_id:
            Graph.clear()
            print("No active trace found. Cannot get graph.")
            return None
            
        graph = Graph.get()
        if not graph:
            graph = TraceGraph(trace_id)
            Graph.set(graph)

        return graph
    
    def add_span(self, name=None, span_type=None):

        graph = self._get_graph()
        parent_id = CurrentSpan.get()
        trace_id = Trace.get()

        if not trace_id:
            print("No active trace found. Cannot add span.")
            return None

        span = Span(trace_id, parent_id,  name, span_type)

        span_id = span.span_id
        graph.add_span(span)

        CurrentSpan.set(span_id)
        
        return span
    
    def get_current_span(self):
        graph = self._get_graph()
        span_id = CurrentSpan.get()

        if not graph or not span_id:
            print("No active graph and span found.")
            return None

        span = graph.get_span(span_id)

        return span

    def start_span(self):
        span = self.get_current_span()

        if not span:
            print("No active span found to start.")
            return None

        span.start_span()
    
    def end_span(self, span_extra=None):
        span = self.get_current_span()

        if not span:
            print("No active span found to end.")
            return None

        try:
            span.end_span(span_extra)
        except Exception as e:
            print(e)
            self.retry_span(span)
        finally:
            graph = self._get_graph()
            if not graph:
                raise Exception("No active graph found to end span.")
            graph.add_outcome(span)
            # graph.build_span_event_flow(span)
            CurrentSpan.set(span.parent_span_id)

        return span

    def retry_span(self, span:Span, span_extra=None):
        span.start_span()
        time.sleep(0.4)
        span.end_span(span_extra)
        return span

    def get_data_span(self):
        span = self.get_current_span()
        if not span:
            print("span not found")
            return None
        return span.data

    def clear(self):
        Graph.clear()
        Trace.clear()
        CurrentSpan.clear()



### old span contex 
_span_stack = ContextVar("span_stack", default=[])


def _now_ms():
    return int(time.time() * 1000)

def start_span(name: str, span_type: str = "INTERNAL"):

    span_id = str(uuid.uuid4())

    # ⚠️ always copy (ContextVar safety)
    stack = list(_span_stack.get() or [])

    parent_id = stack[-1]["span_id"] if stack else None

    span = {
        "span_id": span_id,
        "parent_span_id": parent_id,
        "name": name,
        "type": span_type,
        "start_time": Span._now_ms()
    }

    stack.append(span)
    _span_stack.set(stack)

    return span


def end_span(extra_data=None):

    stack = list(_span_stack.get() or [])

    if not stack:
        return None

    span = stack.pop()
    _span_stack.set(stack)

    span["end_time"] = Span._now_ms()
    span["duration_ms"] = span["end_time"] - span["start_time"]

    if extra_data:
        span.update(extra_data)

    return span

# 🔥 CURRENT SPAN
@staticmethod
def get_current_span():

    stack = _span_stack.get() or []
    return stack[-1] if stack else None

# 🔥 CLEAR (IMPORTANT)
@staticmethod
def clear():
    _span_stack.set([])