import uuid
from datetime import datetime, timezone
from agent_sdk.config.setting import AgentConfig
from agent_sdk.core.identity import Identity
from agent_sdk.core.severity import get_severity
from agent_sdk.core.context import Trace

def current_utc():
    return datetime.now(timezone.utc).isoformat()


def build_event(event_type, category, status, data, metrics=None):
    trace_id = Trace.get() if Trace.get() else None

    return {
        "meta": {
            "sdk_version": AgentConfig.sdk_version,
            "schema_version": AgentConfig.schema_version,
            "timestamp": current_utc(),
            "trace_id": trace_id,
            "project": AgentConfig.project,
            "environment": AgentConfig.environment
        },

        "identity": Identity.collect(),

        "event": {
            "event_id": str(uuid.uuid4()),
            "category": category,
            "type": event_type,
            "severity": get_severity(event_type),
            "status": status,
            "metrics": metrics or {},
            "data": data
        }
    }

