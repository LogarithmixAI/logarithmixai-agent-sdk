SEVERITY_MAP = {

    # =========================
    # 🔵 REQUEST EVENTS
    # =========================
    "INCOMING_REQUEST": "LOW",
    "RESPONSE": "LOW",

    "REQUEST_SUCCESS_FAST": "LOW",
    "REQUEST_SUCCESS_SLOW": "MEDIUM",

    "REQUEST_FAILED_CLIENT": "MEDIUM",
    "REQUEST_FAILED_ROUTING": "MEDIUM",

    "REQUEST_FAILED_SERVER": "HIGH",
    "REQUEST_FAILED_APPLICATION": "HIGH",
    "REQUEST_SLOW_FAILURE": "HIGH",

    "REQUEST_TIMEOUT": "CRITICAL",
    "REQUEST_EXCEPTION": "HIGH",
    "ERROR_RESPONSE": "HIGH",


    # =========================
    # 🌐 HTTP EVENTS (External API)
    # =========================
    "HTTP_SUCCESS": "LOW",
    "HTTP_SLOW": "MEDIUM",

    "HTTP_FAILED_CLIENT": "MEDIUM",
    "HTTP_UNAUTHORIZED": "MEDIUM",
    "HTTP_FORBIDDEN": "MEDIUM",
    "HTTP_NOT_FOUND": "LOW",
    "HTTP_RATE_LIMITED": "MEDIUM",

    "HTTP_FAILED_SERVER": "HIGH",
    "HTTP_BAD_GATEWAY": "HIGH",
    "HTTP_SERVICE_UNAVAILABLE": "HIGH",
    "HTTP_GATEWAY_TIMEOUT": "HIGH",

    "HTTP_EXCEPTION": "HIGH",
    "HTTP_SLOW_FAILURE": "HIGH",

    "HTTP_TIMEOUT": "CRITICAL",
    "HTTP_NOT_FOUND": "LOW",

    # =========================
    # 🗄️ DATABASE EVENTS
    # =========================
    "DB_SUCCESS": "LOW",
    "DB_SLOW": "MEDIUM",

    "DB_FAILED": "HIGH",
    "DB_SLOW_FAILURE": "HIGH",

    "DB_TIMEOUT": "CRITICAL",
    "DB_CONNECTION_FAILED": "CRITICAL",
    "DB_DEADLOCK": "HIGH",
    "DB_INTEGRITY_ERROR": "MEDIUM",
    "DB_SYNTAX_ERROR": "MEDIUM",


    # =========================
    # ⚙️ FUNCTION EVENTS
    # =========================
    "FUNCTION_SUCCESS": "LOW",
    "FUNCTION_SLOW": "MEDIUM",

    "FUNCTION_FAILED": "HIGH",
    "FUNCTION_SLOW_FAILURE": "HIGH",

    "FUNCTION_TIMEOUT": "CRITICAL",


    # =========================
    # 📝 LOG EVENTS
    # =========================
    "LOG_INFO": "LOW",
    "LOG_WARNING": "MEDIUM",

    "LOG_ERROR": "HIGH",
    "LOG_CRITICAL": "CRITICAL",

    "LOG_TIMEOUT": "HIGH",
    "LOG_CONNECTION_ERROR": "HIGH",

    "LOG_DB_DEADLOCK": "HIGH",
    "LOG_DB_INTEGRITY": "MEDIUM",

    "LOG_AUTH_ERROR": "MEDIUM",
    "LOG_PERMISSION_DENIED": "MEDIUM",


    # =========================
    # 🚨 EXCEPTION EVENTS
    # =========================
    "EXCEPTION_GENERAL": "HIGH",

    "EXCEPTION_TIMEOUT": "CRITICAL",
    "EXCEPTION_CONNECTION_ERROR": "HIGH",

    "EXCEPTION_DB_INTEGRITY": "MEDIUM",
    "EXCEPTION_DB_DEADLOCK": "HIGH",

    "EXCEPTION_AUTH_ERROR": "MEDIUM",
    "EXCEPTION_PERMISSION_DENIED": "MEDIUM",

    "EXCEPTION_PROGRAMMING_ERROR": "HIGH",
    "EXCEPTION_VALIDATION_ERROR": "MEDIUM",

    "EXCEPTION_CRITICAL": "CRITICAL",
}


def get_severity(event_type):
    return SEVERITY_MAP.get(event_type, "LOW")
