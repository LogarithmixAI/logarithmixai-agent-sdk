from .config import AgentConfig
from .sender import Sender
from .exceptions import ExceptionTracker
from .network import install_http_patch
from .logging_capture import install_logging


class Agent:

    _initialized = False

    @classmethod
    def init(
        cls,
        *,
        api_key: str,
        api_secret: str,
        endpoint: str,
        project: str,
        environment: str = "production",
        sensitive_keys: list = [
            "password",
            "passwd",
            "pwd",
            "passcode",
            "pin",
            "otp"
        ],
        framework: str | None = None,
        app=None,
        db_engine=None,
        enable_exceptions: bool = True,
        enable_http: bool = True,
        enable_logging: bool = True,
        enable_performance: bool = False
    ):
        """
        Initialize the Monitoring Agent SDK.

        This method configures and starts the agent with various modules like:
        - Exception tracking
        - HTTP request monitoring
        - Logging capture
        - Framework integrations (Flask, FastAPI, Django)
        - Database monitoring
        - Background event sender

        --------------------------------------------------
        🔑 Required Parameters
        --------------------------------------------------
        api_key : str
            Public API key for authentication.

        api_secret : str
            Secret key used for secure communication.

        endpoint : str
            Server endpoint where events/logs will be sent.

        project : str
            Project name (used for grouping logs in dashboard).

        --------------------------------------------------
        ⚙️ Optional Configuration
        --------------------------------------------------
        environment : str (default="production")
            Environment name (e.g., development, staging, production).

        sensitive_keys : list[str]
            List of sensitive keys to mask in logs.

            👉 These keys are:
            - Automatically merged with default internal sensitive keys
            - Matched using partial matching (e.g., "password" matches "user_password")

            Examples:
                ["token", "secret_key", "auth"]

            ⚠️ Note:
                Avoid very generic keys like "id" or "data"
                as they may over-mask useful information.

        framework : str | None
            Supported values:
                - "flask"
                - "fastapi"
                - "django"

        app : object
            Application instance (required for framework integration).

        db_engine : object
            SQLAlchemy engine instance for DB monitoring.

        --------------------------------------------------
        🧩 Feature Toggles
        --------------------------------------------------
        enable_exceptions : bool
            Enable automatic exception tracking.

        enable_http : bool
            Enable HTTP request monitoring (requests patching).

        enable_logging : bool
            Capture Python logging module logs.

        enable_performance : bool
            Reserved for future performance monitoring features.

        --------------------------------------------------
        🚀 Behavior
        --------------------------------------------------
        - Initializes only once (idempotent)
        - Starts background sender thread
        - Hooks into selected modules automatically

        --------------------------------------------------
        💡 Example Usage
        --------------------------------------------------
        Agent.init(
            api_key="your_key",
            api_secret="your_secret",
            endpoint="http://localhost:8000",
            project="my_project",
            sensitive_keys=["custom_token", "private_key"],
            framework="fastapi",
            app=app
        )
        """

        if cls._initialized:
            return

        # ----------------------------
        # Core Configuration
        # ----------------------------
        AgentConfig.api_key = api_key
        AgentConfig.api_secret = api_secret
        AgentConfig.endpoint = endpoint
        AgentConfig.project = project
        AgentConfig.environment = environment

        # ✅ Merge-safe sensitive keys (handled later in sanitizer)
        AgentConfig.sensitive_keys = sensitive_keys

        # ----------------------------
        # Install Core Modules
        # ----------------------------
        if enable_exceptions:
            ExceptionTracker.install()

        if enable_http:
            install_http_patch()

        if enable_logging:
            install_logging()

        # ----------------------------
        # Framework Integration
        # ----------------------------
        if framework and app:

            framework = framework.lower()

            if framework == "flask":
                from .integrations.flask import init_flask
                init_flask(app)

            elif framework == "fastapi":
                from .integrations.fastapi import init_fastapi
                init_fastapi(app)

            elif framework == "django":
                from .integrations.django import init_django
                init_django()

            else:
                raise ValueError(f"Unsupported framework: {framework}")

        # ----------------------------
        # Database Monitoring
        # ----------------------------
        if db_engine:
            from .database import install_sqlalchemy_monitor
            install_sqlalchemy_monitor(db_engine)

        # ----------------------------
        # Performance Module (optional)
        # ----------------------------
        if enable_performance:
            from .performance import monitor_performance
            # Reserved for future use

        # ----------------------------
        # Start Background Sender
        # ----------------------------
        Sender.start()

        cls._initialized = True