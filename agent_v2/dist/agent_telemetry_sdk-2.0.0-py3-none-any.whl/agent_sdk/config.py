class AgentConfig:
    api_key: str = None
    api_secret: str = None   # NEW
    endpoint: str = None
    project: str = None
    environment: str = "production"
    sdk_version: str = "2.0.0"
    schema_version: str = "1.0"
    sensitive_keys = []

    # ✅ regex patterns (user can extend)
    sensitive_patterns = [
        r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",  # email
        r"\b\d{10}\b",  # phone (simple)
        r"\b\d{12}\b",  # aadhaar (basic)
        r"Bearer\s+[A-Za-z0-9\-\._~\+\/]+=*",  # JWT token
    ]
